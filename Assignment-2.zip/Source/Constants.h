// I keep my all constants values here So I don't need to declare them in code everywhere.

const float TRAVEL_SPEED_LASER = 10.f;
const float TRAVEL_SPEED_ROCKS = 3.f;
const int TRAVEL_SPEED_SHIP = 8;
const int TRAVEL_SPEED_SHIP_CHARGING = 4;
const float TRAVEL_SPEED_COIN = 2.f;
const float TRAVEL_SPEED_PARTICLE = 8.f;
const float TRAVEL_SPEED_SMASHED_PARTICLES = 5.f;

